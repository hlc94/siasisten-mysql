<?php

$connect=mysqli_connect('localhost','root','','mkdb_dev');

if(mysqli_connect_errno($connect))
{
	echo 'Fail';
}
?>
