<?php include '../model/database.php';
session_start();

if(!$_SESSION['accID'])  
{  
  header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
}  
?>

<html lang="en">
<head>
  <script type="text/javascript" src="jquery-1.7.2.min.js"></script>
  <script type="text/javascript" src="functions.js"></script>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Starter Template - Materialize</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
<div class="navbar-fixed">
  <nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper container">
      <ul id="dropdown1" class="dropdown-content">
        <li><a href="updateacc.php">Edit akun</a></li>
        <li><a href="viewAddress.php">Lihat alamat</a></li>      
        <li><a href="passport.php">Passport credentials</a></li> 
        <?php 
      if($_SESSION["accID"]=="admin") {
        echo "<li><a href='showpricebook.php'>price book</a></li>
        <li><a href='viewItems.php'>Manage item list</a></li>";
      } else {
        echo "";
      }
      ?>
      </ul>
      <ul id="dropdown2" class="dropdown-content">
        <li><a href="viewcart.php">Shopping cart</a></li>
        <li><a href="katalog.php">Item list</a></li>
        <li><a href="viewPastOrders.php">View order history</a></li>
      </ul>
      <ul id="dropdown3" class="dropdown-content">
        <li><a href="itiView.php">View Itinerary</a></li>
        <li><a href="tempItiView.php">Confirm Itinerary</a></li>
      </ul>
      <ul id="dropdown4" class="dropdown-content">
      <li><a href="maketrip.php">Order pickup</a></li>
      <li><a href="orderhandled_history.php">History</a></li>
    </ul>
      <a href="welcome.php" id="logo-container" href="#" class="brand-logo">Home</a>
      <ul class="right hide-on-med-and-down">
        <li><a class="dropdown-button" href="#!" data-activates="dropdown1">User data<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown2">Shop<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown3">Itinerary<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown4">Order handling<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a href="logout.php?logout">Logout</a></li>
      </ul>

      <ul id="slide-out" class="side-nav">
        <li class="no padding">
          <ul class="collapsible collapsible-accordion">
            <li>
              <a class="collapsible-header">User data</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="updateacc.php">Edit akun</a></li>
                  <li><a href="viewAddress.php">Lihat alamat</a></li>      
                  <li><a href="passport.php">Passport credentials</a></li> 
                  <?php 
      if($_SESSION["accID"]=="admin") {
        echo "<li><a href='showpricebook.php'>price book</a></li>
        <li><a href='viewItems.php'>Manage item list</a></li>";
      } else {
        echo "";
      }
      ?>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Shop</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="viewcart.php">Shopping cart</a></li>
                  <li><a href="katalog.php">Item list</a></li>
                  <li><a href="viewPastOrders.php">View order history</a></li>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Itinerary</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="itiView.php">View Itinerary</a></li>
                  <li><a href="tempItiView.php">Confirm Itinerary</a></li>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Order handling</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="maketrip.php">Order pickup</a></li>
                  <li><a href="orderhandled_history.php">History</a></li>
                </ul>
              </div>
            </li>
            <li>
              <a href="logout.php?logout">Logout</a>
            </li>
          </ul>
        </li>
      </ul>
      <a href="#" data-activates="slide-out" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>
  </div>
  <div class="section no-pad-bot" id="index-banner">
    <div class="container">
      <br><br>
      <h1 class="header center orange-text">Order History</h1>
      <div class="row center">
        <?php
        $accIDSession=$_SESSION["accID"];
        $sql = "SELECT DISTINCT a.orderID, a.orderDetailID, a.pbID, `description`, type, itemNumber, brand, dimH, dimW, dimD, weight, currency, amount, courierFee, c.addrShipID, b.imgPath
                FROM orderdetail a
                INNER JOIN item b ON a.pbID=b.itemID
                INNER JOIN orders c ON a.orderID=c.orderID
                WHERE a.accIDBuyer='$accIDSession'
                ORDER BY a.orderDetailID DESC";
        $result = $connect->query($sql);

        if ($result->num_rows > 0) {
          echo "<div style='overflow-x:auto'>
          <table class='bordered highlight'>
          <thead>
          <tr>
            <th></th>
            <th>Order ID</th>
            <th>Detail ID</th>
            <th>Item ID</th>
            <th>Description</th>
            <th>Type</th>
            <th>Item Number</th>
            <th>Brand</th>
            <th>H</th>
            <th>W</th>
            <th>D</th>
            <th>Weight</th>
            <th>Currency</th>
            <th>Amount</th>
            <th>Courier Fee</th>
            <th>Delivery Address</th>
            
          </tr>
          </thead>";
		    // output data of each row
          while($row = $result->fetch_assoc()) {
            echo "<tbody>
            <tr>
            <td><img src='".$row["imgPath"]."' width='50' height='50'></td>
            <td>".$row["orderID"]."</td>
            <td>".$row["orderDetailID"]."</td>
            <td>".$row["pbID"]."</td>
            <td>".$row["description"]."</td>
            <td>".$row["type"]."</td>
            <td>".$row["itemNumber"]."</td>
            <td>".$row["brand"]."</td>
            <td>".$row["dimH"]."</td>
            <td>".$row["dimW"]."</td>
            <td>".$row["dimD"]."</td>
            <td>".$row["weight"]."</td>
            <td>".$row["currency"]."</td>
            <td>".$row["amount"]."</td>
            <td>".$row["courierFee"]."</td>
            <td>".$row["addrShipID"]."</td>

          </tr>
          </tbody>";
        }
          //$id = $row["pbID"];
          //$_SESSION['sessionPB'] = $id;
        echo "</table>
        </div>";
      } else {
        echo "0 results";
      }
      $connect->close();
      ?>
    </div>
  </div>






  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

</body>
</html>