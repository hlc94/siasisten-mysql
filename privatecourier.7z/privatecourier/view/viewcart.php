<?php include '../model/database.php';
session_start();

if(!$_SESSION['accID'])  
{  
  header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
}  
?>
  
<html lang="en">
<head>
  <script type="text/javascript" src="jquery-1.7.2.min.js"></script>
  <script type="text/javascript" src="functions.js"></script>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Starter Template - Materialize</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
<div class="navbar-fixed">
  <nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper container">
    <ul id="dropdown1" class="dropdown-content">
      <li><a href="updateacc.php">Edit akun</a></li>
      <li><a href="viewAddress.php">Lihat alamat</a></li>      
      <li><a href="passport.php">Passport credentials</a></li> 
      <?php 
      if($_SESSION["accID"]=="admin") {
        echo "<li><a href='showpricebook.php'>price book</a></li>
        <li><a href='viewItems.php'>Manage item list</a></li>";
      } else {
        echo "";
      }
      ?>
    </ul>
    <ul id="dropdown2" class="dropdown-content">
      <li><a href="viewcart.php">Shopping cart</a></li>
      <li><a href="katalog.php">Item list</a></li>
      <li><a href="viewPastOrders.php">View order history</a></li>
    </ul>
    <ul id="dropdown3" class="dropdown-content">
      <li><a href="itiView.php">View Itinerary</a></li>
      <li><a href="tempItiView.php">Confirm Itinerary</a></li>
    </ul>
      <ul id="dropdown4" class="dropdown-content">
      <li><a href="maketrip.php">Order pickup</a></li>
      <li><a href="orderhandled_history.php">History</a></li>
    </ul>
      <a href="welcome.php" id="logo-container" href="#" class="brand-logo">Home</a>
      <ul class="right hide-on-med-and-down">
        <li><a class="dropdown-button" href="#!" data-activates="dropdown1">User data<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown2">Shop<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown3">Itinerary<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown4">Order handling<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a href="logout.php?logout">Logout</a></li>
      </ul>

      <ul id="slide-out" class="side-nav">
        <li class="no padding">
          <ul class="collapsible collapsible-accordion">
            <li>
              <a class="collapsible-header">User data</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="updateacc.php">Edit akun</a></li>
                  <li><a href="viewAddress.php">Lihat alamat</a></li>   
                  <li><a href="passport.php">Passport credentials</a></li>    
                  <?php 
      if($_SESSION["accID"]=="admin") {
        echo "<li><a href='showpricebook.php'>price book</a></li>
        <li><a href='viewItems.php'>Manage item list</a></li>";
      } else {
        echo "";
      }
      ?>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Shop</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="viewcart.php">Shopping cart</a></li>
                  <li><a href="katalog.php">Item list</a></li>
                  <li><a href="viewPastOrders.php">View order history</a></li>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Itinerary</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="itiView.php">View Itinerary</a></li>
                  <li><a href="tempItiView.php">Confirm Itinerary</a></li>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Order handling</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="maketrip.php">Order pickup</a></li>
                  <li><a href="orderhandled_history.php">History</a></li>
                </ul>
              </div>  
            </li>
            <li>
              <a href="logout.php?logout">Logout</a>
            </li>
          </ul>
        </li>
      </ul>
    <a href="#" data-activates="slide-out" class="button-collapse"><i class="material-icons">menu</i></a>
   </div>
 </nav>
 </div>
  <div class="section no-pad-bot" id="index-banner">
    <div class="container">
      <br><br>
      <h1 class="header center orange-text">Shopping Cart</h1>
      <div class="row center">
        <?php
        $accID=$_SESSION["accID"];
        $sql = "SELECT a.pbID, c.brand, c.type, c.description, a.dimH, a.dimW, a.dimD, a.weight, a.currency, a.amount, a.courierFee
                FROM ordertemp a
                INNER JOIN pricebook b ON a.pbID=b.pbID
                INNER JOIN item c ON b.itemID=c.itemID
                WHERE accIDBuyer='$accID'";
        $result = $connect->query($sql);

        if ($result->num_rows > 0) {
          echo "
          <form method='post' action='../controller/orderprocess.php'>
          <div style='overflow-x:auto'>
                  <table class='highlight bordered'>
                  <thead>
                    <tr>
                      <th>Price Book ID</th>
                      <th>brand</th>
                      <th>type</th>
                      <th>description</th>
                      <th>Height</th>
                      <th>Width</th>
                      <th>Depth</th>
                      <th>Weight</th>
                      <th>currency</th>
                      <th>amount</th>
                      <th>courier fee</th>
                      <th></th>
                    </tr>
                    </thead>";
		    // output data of each row
          while($row = $result->fetch_assoc()) {
            echo "<tbody>
            <tr>
                    <td><input type='hidden' name='pbID[]' value='".$row["pbID"]."'>".$row["pbID"]."</td>
                    <td>".$row["brand"]."</td>
                    <td>".$row["type"]."</td>
                    <td>".$row["description"]."</td>
                    <td><input type='hidden' name='dimH[]' value='".$row["dimH"]."'>".$row["dimH"]."</td>
                    <td><input type='hidden' name='dimW[]' value='".$row["dimW"]."'>".$row["dimW"]."</td>
                    <td><input type='hidden' name='dimD[]' value='".$row["dimD"]."'>".$row["dimD"]."</td>
                    <td><input type='hidden' name='weight[]' value='".$row["weight"]."'>".$row["weight"]."</td>
                    <td><input type='hidden' name='currency[]' value='".$row["currency"]."'>".$row["currency"]."</td>
                    <td><input type='hidden' name='amount[]' value='".$row["amount"]."'>".$row["amount"]."</td>
                    <td><input type='hidden' name='courierFee[]' value='".$row["courierFee"]."'>".$row["courierFee"]."</td>
                    <td><a href='deletefromcart.php?id=".$row["pbID"]."&h=".$row["dimH"]."&w=".$row["dimW"]."&d=".$row["dimD"]."&weight=".$row["weight"]."&currency=".$row["currency"]."&amount=".$row["amount"]."&fee=".$row["courierFee"]."'>Delete</td>
                  </tr>
                  </tbody>";
          }
          echo "</table>
          </div>
          <div class='row center'>
            <div class='input-field col s4'>
              <select name='addrShipID' class='browser-default center'>
                <option value='' disabled selected>Choose your delivery address</option>";
               
                $sql2="SELECT addrID 
                      FROM accaddr
                      WHERE accID='$accID'";

                $result2=$connect->query($sql2);

                if($result2->num_rows > 0){
                  while($row2=$result2->fetch_assoc()) {
                    echo "<option value='".$row2["addrID"]."'>".$row2["addrID"]."</option>";
                  }
                }  
              
              echo "</select>
              <label for='dimH' class='active'>Delivery address</label>
            </div>
          </div>
          <button class='btn waves-effect waves-light' type='submit' name='action'>Submit order<i class='material-icons right'>send</i></button>
          </form>";
        } else {
          echo "0 results";
        }
        $connect->close();
        ?><br>
        <a href="katalog.php">Return to catalogue</a>
      </div>
    </div>





    <!--  Scripts-->
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="js/materialize.js"></script>
    <script src="js/init.js"></script>

  </body>
  </html>