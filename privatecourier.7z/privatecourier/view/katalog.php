<?php include '../model/database.php';
session_start();

if(!$_SESSION['accID'])  
{  
  header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
}  
?>
  
<html lang="en">
<head>
  <script type="text/javascript" src="jquery-1.7.2.min.js"></script>
  <script type="text/javascript" src="functions.js"></script>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Starter Template - Materialize</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
  <nav class="light-blue lighten-1 navbar-fixed" role="navigation">
    <div class="nav-wrapper container">
    <ul id="dropdown1" class="dropdown-content">
      <li><a href="updateacc.php">Edit akun</a></li>
      <li><a href="viewAddress.php">Lihat alamat</a></li>      
      <li><a href="passport.php">Passport credentials</a></li> 
      <?php 
      if($_SESSION["accID"]=="admin") {
        echo "<li><a href='showpricebook.php'>price book</a></li>
        <li><a href='viewItems.php'>Manage item list</a></li>";
      } else {
        echo "";
      }
      ?>
    </ul>
    <ul id="dropdown2" class="dropdown-content">
      <li><a href="viewcart.php">Shopping cart</a></li>
      <li><a href="katalog.php">Item list</a></li>
      <li><a href="viewPastOrders.php">View order history</a></li>
    </ul>
    <ul id="dropdown3" class="dropdown-content">
      <li><a href="itiView.php">View Itinerary</a></li>
      <li><a href="tempItiView.php">Confirm Itinerary</a></li>
    </ul>
      
      <ul id="dropdown4" class="dropdown-content">
      <li><a href="maketrip.php">Order pickup</a></li>
      <li><a href="orderhandled_history.php">History</a></li>
    </ul>
      <a href="welcome.php" id="logo-container" href="#" class="brand-logo">Home</a>
      <ul class="right hide-on-med-and-down">
        <li><a class="dropdown-button" href="#!" data-activates="dropdown1">User data<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown2">Shop<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown3">Itinerary<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown4">Order handling<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a href="logout.php?logout">Logout</a></li>
      </ul>

      <ul id="slide-out" class="side-nav">
        <li class="no padding">
          <ul class="collapsible collapsible-accordion">
            <li>
              <a class="collapsible-header">User data</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="updateacc.php">Edit akun</a></li>
                  <li><a href="viewAddress.php">Lihat alamat</a></li>      
                  <li><a href="passport.php">Passport credentials</a></li> 
                  <?php 
      if($_SESSION["accID"]=="admin") {
        echo "<li><a href='showpricebook.php'>price book</a></li>
        <li><a href='viewItems.php'>Manage item list</a></li>";
      } else {
        echo "";
      }
      ?>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Shop</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="viewcart.php">Shopping cart</a></li>
                  <li><a href="katalog.php">Item list</a></li>
                  <li><a href="viewPastOrders.php">View order history</a></li>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Itinerary</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="itiView.php">View Itinerary</a></li>
                  <li><a href="tempItiView.php">Confirm Itinerary</a></li>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Order handling</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="maketrip.php">Order pickup</a></li>
                  <li><a href="orderhandled_history.php">History</a></li>
                </ul>
              </div>
            </li>
            <li>
              <a href="logout.php?logout">Logout</a>
            </li>
          </ul>
        </li>
      </ul>
    <a href="#" data-activates="slide-out" class="button-collapse"><i class="material-icons">menu</i></a>
   </div>
 </nav>
  <div class="section no-pad-bot" id="index-banner">
    <div class="container">
      <br><br>
      <h1 class="header center orange-text">Catalogue</h1>
      <div class="row center col s12">
        <?php

          /*1. select country from pricebook
            2. create select form w/ action=post with countries as option value
            3. if $_POST = empty -> show all
               else $country=$_POST[option value]
               SELECT pbID, a.itemID, `description`, type, itemNumber, brand, currency, sellPrice, courierFee, itemCOGS, handlingCost, tax, active, countryISOCode
               FROM item a 
               JOIN pricebook b ON a.itemID=b.itemID
               WHERE b.countryISOCode=$country*/

          echo "<form method='get' action=''>
                  <div class='input-field col s4 center'>
                    <select name='countryISOCode' class='browser-default' id='1'>
                      <option value='' disabled selected>Select Country</option>";

          $sql1="SELECT DISTINCT countryISOCode 
                 FROM pricebook";

          $result1=$connect->query($sql1);

          if($result1->num_rows > 0){
            while($row1=$result1->fetch_assoc()) {
              echo "<option value='".$row1["countryISOCode"]."'>".$row1["countryISOCode"]."</option>";
            }
          }

          echo "</select>
          </div>
          <div class='input-field col s4 center'>
          <select name='currency' class='browser-default' id='2'>
            <option value='' disabled selected>Select currency</option>";

          $sql3="SELECT DISTINCT currency 
                 FROM pricebook";

          $result3=$connect->query($sql3);

          if($result3->num_rows > 0){
            while($row3=$result3->fetch_assoc()) {
              echo "<option value='".$row3["currency"]."'>".$row3["currency"]."</option>";
            }
          }

          echo "</select></div>
          <div class='input-field col s4 center'>
          <select name='priceRange' class='browser-default' id='3'>
            <option value='' disabled selected>All price range</option>
            <option value='<1000'><1000</option>
            <option value='1000-5000'>1000-5000</option>
            <option value='5000-10000'>5000-10000</option>
            <option value='10000-100000'>10000-100000</option>
            <option value='>100000'>>100000</option>
          </select>
          </div>";

          echo "</div>
          <center><input type='submit' name='submit' value='Filter'></center>
          </form>
          </div>";

          $sql2="SELECT pbID, a.itemID, `description`, type, itemNumber, brand, currency, sellPrice, courierFee, itemCOGS, handlingCost, tax, active, countryISOCode, imgPath
                   FROM item a 
                   JOIN pricebook b ON a.itemID=b.itemID";

          if (isset($_GET["countryISOCode"]))
          {
            $country=$_GET["countryISOCode"];
            $sql2 .= " WHERE countryISOCode='$country'";
          } 
          else if (isset($_GET["currency"]))
          {
            $currency=$_GET["currency"];
            $sql2 .= " WHERE currency='$currency'";
          }
          else if (isset($_GET["priceRange"]))
          {
            $priceRange=$_GET["priceRange"];
            if ($priceRange=="<1000")
            {
              $sql2.=" WHERE sellPrice < 1000";
            } 
            else if ($priceRange=="1000-5000")
            {
              $sql2.=" WHERE sellPrice >= 1000 AND sellPrice <= 5000";
            } 
            else if ($priceRange=="5000-10000")
            {
              $sql2.=" WHERE sellPrice >= 5000 AND sellPrice <= 10000";
            }
            else if ($priceRange=="10000-100000")
            {
              $sql2.=" WHERE sellPrice >= 10000 AND sellPrice <= 100000";
            }
            else if ($priceRange==">100000")
            {
              $sql2.=" WHERE sellPrice > 100000";
            }
          }
          else if (isset($_GET["countryISOCode"]) && isset($_GET["currency"]))
          {
            $country=$_GET["countryISOCode"];
            $currency=$_GET["currency"];
            $sql2 .= " WHERE countryISOCode='$countryISOCode' AND currency='$currency'";
          }
          else 
          {
            $sql2;
          }

          $sql2;
          $result2=$connect->query($sql2);

            if($result2->num_rows > 0) 
            {
              echo "<br><div class='row center col s12'>
                      <ul class='products'>"; 
              while($row2=$result2->fetch_assoc()) 
              {
                echo "<li>
                        <a href='order.php?pb=".$row2["pbID"]."'>
                        <img src='".$row2["imgPath"]."' width='150'>
                        <h5>".$row2["brand"]." ".$row2["type"]."</h5>
                        <p>
                        ".$row2["description"]."<br>
                        ".$row2["countryISOCode"]."<br>
                        ".$row2["currency"]." ".$row2["sellPrice"]."
                        </p>
                        </a>
                      </li>";
              }
              echo "</ul>
              </div>

          </div>";

            }
            else {
              echo "<br><center>No results</center> ";
            }

          $connect->close();
        ?>
      </div>
    </div>
    </div>

    <!--  Scripts-->
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="js/materialize.js"></script>
    <script src="js/init.js"></script>

  </body>
  </html>

  <!-- /*$sql = "SELECT pbID, a.itemID, `description`, type, itemNumber, brand, currency, sellPrice, courierFee, itemCOGS, handlingCost, tax, active, countryISOCode
          FROM item a 
          JOIN pricebook b ON a.itemID=b.itemID";
          $result = $connect->query($sql);*/

         /* if ($result->num_rows > 0) {*/
            /*echo "<div style='overflow-x:auto'>
            <table class='bordered highlight'>
            <thead>
                    <tr>
                      <th>Price Book ID</th>
                      <th>Item ID</th>
                      <th>Description</th>
                      <th>Type</th>
                      <th>Item Number</th>
                      <th>Brand</th>
                      <th>Currency</th>
                      <th>Sell Price</th>
                      <th>Courier Fee</th>
                      <th>Item COGS</th>
                      <th>Handling Cost</th>
                      <th>Tax</th>
                      <th>Active</th>
                      <th></th>
                    </tr>
                    </thead>";*/
          // output data of each row
            /*echo "<ul class='products'>";
            while($row = $result->fetch_assoc()) {*/
              /*echo "<tbody>
              <tr>
                  <td>".$row["pbID"]."</td>
                      <td>".$row["itemID"]."</td>
                      <td>".$row["description"]."</td>
                      <td>".$row["type"]."</td>
                      <td>".$row["itemNumber"]."</td>
                      <td>".$row["brand"]."</td>
                      <td>".$row["currency"]."</td>
                      <td>".$row["sellPrice"]."</td>
                      <td>".$row["courierFee"]."</td>
                      <td>".$row["itemCOGS"]."</td>
                      <td>".$row["handlingCost"]."</td>
                      <td>".$row["tax"]."</td>
                      <td>".$row["active"]."</td>
                      <td><a href='order.php?pb=".$row["pbID"]."&it=".$row["itemID"]."'>Place order</td>
                    </tr>
                    </tbody>";*/
                    /*echo "
                            <li>
                              <a href='order.php?pb=".$row["pbID"]."&it=".$row["itemID"]."'>
                              <img src='images/noimage.gif' height='150' width='150'>
                              <h5>".$row["brand"]." ".$row["type"]."</h5>
                              <p>
                              ".$row["description"]."<br>
                              ".$row["countryISOCode"]."<br>
                              ".$row["currency"]." ".$row["sellPrice"]."
                              </p>
                              </a>
                            </li>"; */    
            }
            /*echo </table>
            </div>"*/
            /*echo "</ul>";   
          } else {
            echo "0 results";
          }*/ -->