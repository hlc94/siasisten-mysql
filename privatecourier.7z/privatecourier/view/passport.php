<?php include '../model/database.php';

session_start();

if(!$_SESSION['accID'])  
{  
  header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
} 

?>

<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Starter Template - Materialize</title>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
  <nav class="light-blue lighten-1" role="navigation">
    <div class="nav-wrapper container">
      <ul id="dropdown1" class="dropdown-content">
        <li><a href="updateacc.php">Edit akun</a></li>
        <li><a href="viewAddress.php">Lihat alamat</a></li>   
        <li><a href="passport.php">Passport credentials</a></li>    
        <?php 
        if($_SESSION["accID"]=="admin") {
          echo "<li><a href='showpricebook.php'>price book</a></li>
          <li><a href='viewItems.php'>Manage item list</a></li>";
        } else {
          echo "";
        }
        ?>
      </ul>
      <ul id="dropdown2" class="dropdown-content">
        <li><a href="viewcart.php">Shopping cart</a></li>
        <li><a href="katalog.php">Item list</a></li>
        <li><a href="viewPastOrders.php">View order history</a></li>
      </ul>
      <ul id="dropdown3" class="dropdown-content">
        <li><a href="itiView.php">View Itinerary</a></li>
        <li><a href="tempItiView.php">Confirm Itinerary</a></li>
      </ul><ul id="dropdown4" class="dropdown-content">
      <li><a href="maketrip.php">Order pickup</a></li>
      <li><a href="orderhandled_history.php">History</a></li>
    </ul>
      <a href="welcome.php" id="logo-container" href="#" class="brand-logo">Home</a>
      <ul class="right hide-on-med-and-down">
        <li><a class="dropdown-button" href="#!" data-activates="dropdown1">User data<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown2">Shop<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown3">Itinerary<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown4">Order handling<i class="material-icons right">arrow_drop_down</i></a></li>
        <li><a href="logout.php?logout">Logout</a></li>
      </ul>

      <ul id="slide-out" class="side-nav">
        <li class="no padding">
          <ul class="collapsible collapsible-accordion">
            <li>
              <a class="collapsible-header">User data</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="updateacc.php">Edit akun</a></li>
                  <li><a href="viewAddress.php">Lihat alamat</a></li>      
                  <li><a href="passport.php">Passport credentials</a></li> 
                  <?php 
                  if($_SESSION["accID"]=="admin") {
                    echo "<li><a href='showpricebook.php'>price book</a></li>
                    <li><a href='viewItems.php'>Manage item list</a></li>";
                  } else {
                    echo "";
                  }
                  ?>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Shop</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="viewcart.php">Shopping cart</a></li>
                  <li><a href="katalog.php">Item list</a></li>
                  <li><a href="viewPastOrders.php">View order history</a></li>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Itinerary</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="itiView.php">View Itinerary</a></li>
                  <li><a href="tempItiView.php">Confirm Itinerary</a></li>
                </ul>
              </div>  
            </li>
            <li>
              <a class="collapsible-header">Order handling</a>
              <div class="collapsible-body">
                <ul>
                  <li><a href="maketrip.php">Order pickup</a></li>
                  <li><a href="orderhandled_history.php">History</a></li>
                </ul>
              </div> 
            </li>
            <li>
              <a href="logout.php?logout">Logout</a>
            </li>
          </ul>
        </li>
      </ul>
      <a href="#" data-activates="slide-out" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>
  <div class="section no-pad-bot" id="index-banner">
    <div class="container">
      <br><br>
      <h1 class="header center orange-text">Edit Passport Credentials</h1>
      <div class="row center">
        <?php 
          $accIDSession = $_SESSION["accID"];
          $sql = "SELECT * FROM accpassport WHERE passAccID='$accIDSession'";
          $result = $connect->query($sql);

          $row = $result->fetch_assoc();
          echo 
            "<form class='col s12' method='post' action='../controller/passportProcess.php'>
              <div class='row'>
                <div class='input-field col s12'>
                  <input id='passNo' name='passNo' type='text' value='".$row["passNo"]."' >
                  <label for='passNo'>Passport No.</label>
                </div>
              </div>
              <div class='row'>
                <div class='input-field col s12'>
                  <input id='passName' name='passName' type='text' value='".$row["passName"]."'>
                  <label for='passName'>Passport Name</label>
                </div>
              </div>
              <div class='row'>
                <div class='input-field col s12'>
                  <input id='passDOB' name='passDOB' type='date' value='".$row["passDOB"]."'>
                  <label for='passDOB' class='active'>Date of Birth</label>
                </div>
              </div>
              <div class='row'>
                <div class='input-field col s12'>
                  <input id='passPOB' name='passPOB' type='text' value='".$row["passPOB"]."'>
                  <label for='passPOB'>Place of Birth</label>
                </div>
              </div>
              <div class='row'>
                <div class='input-field col s12'>
                  <input id='passNat' name='passNat' type='text' value='".$row["passNat"]."'>
                  <label for='passNat'>Nationality</label>
                </div>
              </div>
              <div class='row'>
                <div class='input-field col s12'>
                  <input id='passDateExp' name='passDateExp' type='date' value='".$row["passDateExp"]."'>
                  <label for='passDateExp' class='active'>Passport Expiration Date</label>
                </div>
              </div>
              <div class='row'>
                <div class='input-field col s12'>
                  <input id='passIssueOff' name='passIssueOff' type='text' value='".$row["passIssueOff"]."'>
                  <label for='passIssueOff'>Issue Off</label>
                </div>
              </div>
              <div class='row center'>
                <button class='btn waves-effect waves-light' type='submit' name='action'>Update<i class='material-icons right'>send</i>
                </div>
              </button>
            </form>";
        ?>
      </div>
      <br><br>

    </div>
  </div>


  




  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

</body>
</html>
