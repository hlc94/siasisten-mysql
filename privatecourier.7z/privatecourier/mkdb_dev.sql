-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2016 at 04:24 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mkdb_dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc`
--

CREATE TABLE `acc` (
  `accID` varchar(50) NOT NULL,
  `accPasswd` varchar(45) NOT NULL,
  `name` varchar(60) NOT NULL,
  `nik` varchar(25) NOT NULL,
  `accDateCreate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `acc`
--

INSERT INTO `acc` (`accID`, `accPasswd`, `name`, `nik`, `accDateCreate`) VALUES
('admin', 'admin', 'Admin', '12352354675754', '2016-08-16 10:26:43'),
('buyer1', 'buyer1', 'Buyer 1', '12345', '2016-08-15 10:44:12'),
('buyer2', 'buyer2', 'Buyer 2', '21151356', '2016-08-15 13:17:32'),
('courier1', 'courier1', 'Courier 1', '12345', '2016-08-15 10:43:50'),
('courier2', 'courier2', 'Courier 2', '30e91023414', '2016-08-15 13:21:34'),
('user', 'user', 'User', '12093102581', '2016-08-16 10:26:58');

-- --------------------------------------------------------

--
-- Table structure for table `accaddr`
--

CREATE TABLE `accaddr` (
  `accID` varchar(50) NOT NULL,
  `addrID` varchar(30) NOT NULL,
  `addrType` char(1) DEFAULT NULL COMMENT 'H=home\nB=billing\nS=ship1, T=ship2, U=ship3, V=ship4, W=ship5',
  `prov` varchar(45) DEFAULT NULL,
  `kota_kab` varchar(45) DEFAULT NULL,
  `kec` varchar(45) DEFAULT NULL,
  `addr` varchar(120) DEFAULT NULL,
  `zip` varchar(7) DEFAULT NULL,
  `countryISOCode` char(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `accaddr`
--

INSERT INTO `accaddr` (`accID`, `addrID`, `addrType`, `prov`, `kota_kab`, `kec`, `addr`, `zip`, `countryISOCode`) VALUES
('buyer1', 'home sweet home', 'H', 'DKI Jakarta', 'Jakarta', 'pondok indah', 'jl metro pondok indah', '12355', 'INA'),
('admin', 'kantor', 'S', 'DKI Jakarta', 'Jakarta', 'Gambir', 'Jl Balikpapan', '12415', 'INA'),
('admin', 'Kosan', 'T', 'Jawa Barat', 'Bandung', 'Coblong', 'Jl ciheulang 6', '40123', 'INA'),
('buyer1', 'numpang ', 'T', 'Jawa Barat', 'Bandung', 'bandung', 'jl re martadinata', '21515', 'INA'),
('admin', 'rumah', '', 'Banten', 'Tangerang Selatan', 'Pamulang', 'Jl. Durian 1 blok E3/2 Pamulang Estate', '15417', 'INA');

-- --------------------------------------------------------

--
-- Table structure for table `accpassport`
--

CREATE TABLE `accpassport` (
  `passAccID` varchar(50) NOT NULL,
  `passNo` varchar(12) NOT NULL,
  `passName` varchar(45) NOT NULL,
  `passDOB` date NOT NULL COMMENT 'passport date of birth',
  `passPOB` varchar(45) NOT NULL COMMENT 'passport place of birth',
  `passNat` varchar(50) NOT NULL COMMENT 'passport nationality',
  `passDateExp` date NOT NULL COMMENT 'passport date of expiry',
  `passIssueOff` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `accpassport`
--

INSERT INTO `accpassport` (`passAccID`, `passNo`, `passName`, `passDOB`, `passPOB`, `passNat`, `passDateExp`, `passIssueOff`) VALUES
('admin', '120391245', 'Admin', '1994-09-20', 'Jakarta', 'Indonesia', '2017-09-20', 'asjdafkaf'),
('courier1', 'ID024578', 'Courier1', '2016-08-19', 'Jakarta', 'Indonesia', '2016-08-19', 'IDN');

-- --------------------------------------------------------

--
-- Table structure for table `accpaymentmethod`
--

CREATE TABLE `accpaymentmethod` (
  `accID` varchar(50) NOT NULL,
  `payID` int(11) DEFAULT NULL,
  `ccIssuer` varchar(45) DEFAULT NULL,
  `ccNo` char(20) DEFAULT NULL,
  `ccName` varchar(45) DEFAULT NULL,
  `ccExpMo` tinyint(4) DEFAULT NULL,
  `ccExpYr` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `itemID` varchar(25) NOT NULL,
  `description` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `itemNumber` varchar(45) DEFAULT NULL,
  `brand` varchar(45) DEFAULT NULL,
  `imgPath` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`itemID`, `description`, `type`, `itemNumber`, `brand`, `imgPath`) VALUES
('034', 'g502 proteus core', 'mouse', '9174', 'logitech', '../model/images/g502proteus.png'),
('123', 'gtx 1080 ftw', 'vga', '314', 'EVGA', '../model/images/evga.jpg'),
('190', 'ripjaws V ram card', 'RAM', '2104', 'G.Skill', '../model/images/gskill v.png'),
('214', 'mech rgb kboard k70', 'k70', '213', 'corsair', '../model/images/g105.jpg'),
('2193412', 'tes preview', 'kboard', '', '', '../model/images/evga.jpg'),
('456', 'flash disk', 'usb', '619', 'kingston', '../model/images/kingston.jpg'),
('759', 'ath m50x', 'headset', '9124', 'audio technica', '../model/images/audio technica.jpg'),
('789', 'ROG series', 'laptop', '214', 'asus', '../model/images/asuspascal.jpg'),
('867', 'i7-6700k unlocked', 'CPU', '201', 'Intel', '../model/images/intel i7.jpg'),
('904', 'cx500 bronze power supply', 'power supply', '2814', 'corsair', '../model/images/corsair cx500.png');

-- --------------------------------------------------------

--
-- Table structure for table `itidetail`
--

CREATE TABLE `itidetail` (
  `itID` varchar(15) DEFAULT NULL,
  `itIDetailID` int(12) NOT NULL,
  `bookNo` varchar(20) NOT NULL,
  `depCountry` varchar(3) NOT NULL,
  `depCity` varchar(50) NOT NULL,
  `depDate` datetime NOT NULL,
  `flightNo` varchar(8) NOT NULL,
  `airline` varchar(45) DEFAULT NULL,
  `arrCountry` varchar(3) NOT NULL,
  `arrCity` varchar(50) NOT NULL,
  `arrDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `itidetail`
--

INSERT INTO `itidetail` (`itID`, `itIDetailID`, `bookNo`, `depCountry`, `depCity`, `depDate`, `flightNo`, `airline`, `arrCountry`, `arrCity`, `arrDate`) VALUES
('jalan-jalan', 16, '1', 'INA', 'Jakarta', '2016-09-01 01:00:00', 'GTX 1080', 'NVidia GeForce', 'INA', 'Bandung', '2016-09-01 10:00:00'),
('ke situ', 17, '1', 'INA', 'Jakarta', '2016-09-01 14:00:00', '', '', 'INA', 'Tangerang Selatan', '2016-09-01 18:00:00'),
('asfakjnf', 18, '10', 'INA', 'Bandung', '2016-08-17 09:00:00', '', '', 'INA', 'Tangerang Selatan', '2016-08-17 15:00:00'),
('nyoba', 19, '101', 'INA', 'Bandung', '2016-09-01 01:00:00', '', '', 'INA', 'Jakarta', '2016-09-01 09:00:00'),
('perjalanan plg ', 20, 'Avshsjsksjs13431', 'INA', 'Jakarta', '2016-08-14 16:45:00', 'GA134457', 'Garuda', 'SNG', 'SNG', '2016-08-15 16:46:00'),
('perjalanan plg ', 21, 'Avshsjsksjs13433', 'SNG', 'Singapore', '2016-08-15 16:50:00', 'GA134458', 'Garuda', 'INA', 'Jakarta', '2016-08-15 17:00:00'),
('perjalanan plg ', 22, 'ASDDFGHJ1234', 'INA', 'Jakarta', '2016-08-09 03:02:00', 'GA123456', 'Garuda', 'THA', 'Bangkok', '2016-08-16 20:10:00'),
('perjalanan plg ', 23, 'fergtyk12435', 'THA', 'Bangkok', '2016-08-18 08:09:00', 'GA234567', 'Garuda', 'INA', 'Jakarta', '2016-08-20 15:34:00'),
('Bolak balik', 24, '1', 'INA', 'Jakarta', '2016-09-01 08:00:00', '', '', 'INA', 'Tangerang Selatan', '2016-09-01 11:00:00'),
('Bolak balik', 25, '2', 'INA', 'Tangerang Selatan', '2016-08-31 01:00:00', '', '', 'INA', 'Jakarta', '2016-08-31 03:00:00'),
('Jalan', 26, '1', 'INA', 'Serpong', '2016-09-10 08:00:00', '', '', 'INA', 'Bandung', '2016-09-10 17:00:00'),
('Sing-Jakarta', 27, 'GA1737372', 'SNG', 'Singapore', '2016-08-20 16:20:00', 'GA134457', 'Garuda', 'INA', 'Jakarta', '2016-08-22 16:32:00'),
('Sing-Jakarta', 28, 'GA1737373', 'INA', 'Jakarta', '2016-08-21 16:22:00', 'GA134458', 'Garuda', 'SNG', 'Singapura', '2016-08-26 16:30:00'),
('jalanjalan', 29, '5', 'JPN', 'Tokyo', '2016-09-20 01:00:00', '', '', 'INA', 'Jakarta', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `itinarary`
--

CREATE TABLE `itinarary` (
  `itID` varchar(15) NOT NULL,
  `accID` varchar(50) NOT NULL,
  `itBookID` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `itinarary`
--

INSERT INTO `itinarary` (`itID`, `accID`, `itBookID`) VALUES
('asfakjnf', 'courier2', 'itBookID'),
('Bolak balik', 'admin', 'itBookID'),
('Jalan', 'admin', 'itBookID'),
('jalan-jalan', 'courier1', 'itBookID'),
('jalanjalan', 'courier1', 'itBookID'),
('ke situ', 'courier1', 'itBookID'),
('nyoba', 'courier1', 'itBookID'),
('perjalanan plg ', 'buyer1', 'itBookID'),
('Sing-Jakarta', 'courier2', 'itBookID');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail`
--

CREATE TABLE `orderdetail` (
  `orderID` int(12) NOT NULL,
  `orderDetailID` int(15) NOT NULL,
  `pbID` int(11) NOT NULL,
  `accIDBuyer` varchar(50) NOT NULL,
  `dimH` smallint(6) DEFAULT NULL,
  `dimW` smallint(6) DEFAULT NULL,
  `dimD` smallint(6) DEFAULT NULL,
  `weight` smallint(6) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL COMMENT 'get shipID pbID to calculate amount',
  `courierFee` decimal(9,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderdetail`
--

INSERT INTO `orderdetail` (`orderID`, `orderDetailID`, `pbID`, `accIDBuyer`, `dimH`, `dimW`, `dimD`, `weight`, `currency`, `amount`, `courierFee`) VALUES
(21, 26, 456, 'buyer2', 0, 0, 0, 0, 'IDR', '199.00', '199.00'),
(23, 28, 456, 'buyer1', 0, 0, 0, 0, 'IDR', '100.00', '1000.00'),
(23, 29, 123, 'buyer1', 0, 0, 0, 0, 'IDR', '10.00', '1000.00'),
(24, 30, 123, 'buyer2', 0, 0, 0, 0, 'IDR', '100.00', '6000.00'),
(25, 31, 123, 'buyer1', 0, 0, 0, 0, 'IDR', '10.00', '1000.00'),
(26, 32, 456, 'admin', 0, 0, 0, 0, 'Usd', '10.00', '100.00'),
(27, 33, 456, 'buyer2', 10, 5, 3, 88, 'IDR', '20.00', '9999999.99'),
(27, 34, 123, 'buyer2', 10, 50, 30, 66, 'IDR', '72.00', '177227.00'),
(28, 35, 456, 'admin', 0, 0, 0, 0, 'USD', '10.00', '100.00'),
(28, 36, 123, 'admin', 0, 0, 0, 0, 'JPY', '50.00', '100.00'),
(29, 37, 456, 'admin', 0, 0, 0, 0, 'USD', '10.00', '1000.00'),
(30, 38, 456, 'admin', 0, 0, 0, 0, 'USD', '10.00', '100.00'),
(30, 39, 123, 'admin', 0, 0, 0, 2, 'IDR', '1.00', '1000.00'),
(31, 40, 456, 'buyer1', 10, 3, 5, 22, 'IDR', '20.00', '9999999.99'),
(31, 41, 123, 'buyer1', 0, 0, 0, 0, 'JPY', '1.00', '1000.00'),
(32, 42, 123, 'buyer1', 0, 0, 0, 0, 'JPY', '1.00', '100.00'),
(33, 43, 4, 'buyer1', 0, 0, 0, 0, 'JPY', '1.00', '10000.00'),
(34, 44, 3, 'buyer1', 0, 0, 0, 0, 'IDR', '1.00', '1000.00'),
(35, 45, 10, 'admin', 0, 0, 0, 0, 'IDR', '1.00', '1000.00');

-- --------------------------------------------------------

--
-- Table structure for table `orderhandled`
--

CREATE TABLE `orderhandled` (
  `ohID` int(15) NOT NULL,
  `orderDetailID` int(15) NOT NULL,
  `itDetail` int(12) NOT NULL,
  `shipCourierFee` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderhandled`
--

INSERT INTO `orderhandled` (`ohID`, `orderDetailID`, `itDetail`, `shipCourierFee`) VALUES
(15, 34, 25, NULL),
(16, 26, 25, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orderhandled_temp`
--

CREATE TABLE `orderhandled_temp` (
  `accID` varchar(50) NOT NULL,
  `orderDetailID` int(15) NOT NULL,
  `itDetail` int(12) NOT NULL,
  `shipCourierFee` decimal(7,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderhandled_temp`
--

INSERT INTO `orderhandled_temp` (`accID`, `orderDetailID`, `itDetail`, `shipCourierFee`) VALUES
('courier1', 31, 17, '0.00'),
('admin', 39, 24, '0.00'),
('courier1', 43, 29, '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderID` int(12) NOT NULL,
  `accIDBuyer` varchar(50) NOT NULL,
  `orderDate` datetime DEFAULT NULL,
  `addrShipID` varchar(30) NOT NULL,
  `payID` varchar(20) DEFAULT NULL,
  `payStatus` char(1) DEFAULT NULL COMMENT 'P=Paid\nU=Unpaid\nO=Other'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderID`, `accIDBuyer`, `orderDate`, `addrShipID`, `payID`, `payStatus`) VALUES
(21, 'buyer2', '2016-08-15 13:25:20', 'rurururu', '1', 'U'),
(23, 'buyer1', '2016-08-15 14:38:55', 'si orang', '1', 'U'),
(24, 'buyer2', '2016-08-15 14:39:56', 'rurururu', '1', 'U'),
(25, 'buyer1', '2016-08-15 16:37:55', 'si orang', '1', 'U'),
(26, 'admin', '2016-08-18 10:51:53', 'home', '1', 'U'),
(27, 'buyer2', '2016-08-18 14:55:00', 'kantor', '1', 'U'),
(28, 'admin', '2016-08-18 15:13:13', '', '1', 'U'),
(29, 'admin', '2016-08-22 13:50:54', 'home', '1', 'U'),
(30, 'admin', '2016-08-26 10:42:55', 'rumah', '1', 'U'),
(31, 'buyer1', '2016-08-26 10:55:31', 'home sweet home', '1', 'U'),
(32, 'buyer1', '2016-08-26 11:06:14', 'home sweet home', '1', 'U'),
(33, 'buyer1', '2016-08-26 11:35:54', 'home sweet home', '1', 'U'),
(34, 'buyer1', '2016-08-26 11:36:13', 'home sweet home', '1', 'U'),
(35, 'admin', '2016-08-26 13:12:41', 'Kosan', '1', 'U');

-- --------------------------------------------------------

--
-- Table structure for table `ordertemp`
--

CREATE TABLE `ordertemp` (
  `accIDBuyer` varchar(20) DEFAULT NULL,
  `pbID` int(11) NOT NULL,
  `dimH` int(10) DEFAULT NULL,
  `dimW` int(10) DEFAULT NULL,
  `dimD` int(10) DEFAULT NULL,
  `weight` int(10) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `amount` int(10) DEFAULT NULL,
  `courierFee` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pricebook`
--

CREATE TABLE `pricebook` (
  `pbID` int(11) NOT NULL,
  `countryISOCode` char(3) NOT NULL,
  `itemID` varchar(45) NOT NULL,
  `currency` char(3) DEFAULT NULL,
  `sellPrice` decimal(10,2) NOT NULL,
  `courierFee` decimal(9,2) NOT NULL,
  `itemCOGS` decimal(10,2) NOT NULL,
  `handlingCost` decimal(7,2) DEFAULT NULL,
  `tax` decimal(10,2) DEFAULT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pricebook`
--

INSERT INTO `pricebook` (`pbID`, `countryISOCode`, `itemID`, `currency`, `sellPrice`, `courierFee`, `itemCOGS`, `handlingCost`, `tax`, `active`) VALUES
(1, 'USA', '456', 'USD', '3000.00', '5.00', '5.00', '10.00', '5.00', 1),
(2, 'USA', '456', 'USD', '100.00', '5.00', '5.00', '10.00', '10.00', 1),
(3, 'INA', '123', 'IDR', '10000000.00', '300000.00', '1000.00', '5000.00', '100000.00', 1),
(4, 'JPN', '123', 'JPY', '75000.00', '5000.00', '1000.00', '1000.00', '1000.00', 1),
(6, 'INA', '214', 'IDR', '1200000.00', '100.00', '1000.00', '1000.00', '1000.00', 1),
(7, 'INA', '2193412', 'IDR', '100.00', '100.00', '1001.00', '100.00', '1000.00', 1),
(8, 'USA', '759', 'USD', '200.00', '50.00', '100.00', '100.00', '10.00', 1),
(9, 'INA', '789', 'IDR', '13000000.00', '50000.00', '500.00', '10000.00', '13000.00', 1),
(10, 'INA', '034', 'IDR', '900000.00', '50000.00', '100.00', '10000.00', '10000.00', 1),
(11, 'USA', '867', 'USD', '400.00', '100.00', '100.00', '50.00', '15.00', 1),
(12, 'JPN', '904', 'JPY', '40000.00', '5000.00', '1000.00', '1000.00', '4000.00', 1),
(13, 'INA', '789', 'USD', '1000.00', '100.00', '100.00', '1000.00', '1000.00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tempitinerary`
--

CREATE TABLE `tempitinerary` (
  `itID` varchar(15) NOT NULL,
  `accID` varchar(50) NOT NULL,
  `bookNo` varchar(20) NOT NULL,
  `depCountry` varchar(3) NOT NULL,
  `depCity` varchar(50) NOT NULL,
  `depDate` datetime NOT NULL,
  `flightNo` varchar(8) NOT NULL,
  `airline` varchar(45) NOT NULL,
  `arrCountry` varchar(3) NOT NULL,
  `arrCity` varchar(50) NOT NULL,
  `arrDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tempitinerary`
--

INSERT INTO `tempitinerary` (`itID`, `accID`, `bookNo`, `depCountry`, `depCity`, `depDate`, `flightNo`, `airline`, `arrCountry`, `arrCity`, `arrDate`) VALUES
('', 'admin', '4', 'INA', 'Jakarta', '2016-01-31 01:00:00', '', '', 'SG', 'Singapore', '2016-09-20 01:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acc`
--
ALTER TABLE `acc`
  ADD PRIMARY KEY (`accID`),
  ADD UNIQUE KEY `accID_UNIQUE` (`accID`);

--
-- Indexes for table `accaddr`
--
ALTER TABLE `accaddr`
  ADD PRIMARY KEY (`addrID`),
  ADD UNIQUE KEY `addID_UNIQUE` (`addrID`),
  ADD KEY `pb_idx` (`accID`,`countryISOCode`),
  ADD KEY `addrCountry` (`countryISOCode`);

--
-- Indexes for table `accpassport`
--
ALTER TABLE `accpassport`
  ADD PRIMARY KEY (`passAccID`),
  ADD KEY `passNo_idx` (`passNo`);

--
-- Indexes for table `accpaymentmethod`
--
ALTER TABLE `accpaymentmethod`
  ADD PRIMARY KEY (`accID`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `itidetail`
--
ALTER TABLE `itidetail`
  ADD PRIMARY KEY (`itIDetailID`),
  ADD KEY `itID_idx` (`itID`);

--
-- Indexes for table `itinarary`
--
ALTER TABLE `itinarary`
  ADD PRIMARY KEY (`itID`),
  ADD KEY `accID_idx` (`accID`),
  ADD KEY `itID` (`itID`);

--
-- Indexes for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD PRIMARY KEY (`orderDetailID`),
  ADD UNIQUE KEY `orderDetailID` (`orderDetailID`),
  ADD KEY `itemID_idx` (`pbID`),
  ADD KEY `orderID_idx` (`orderID`),
  ADD KEY `orderAccIDBuyer` (`accIDBuyer`),
  ADD KEY `orderDetailID_2` (`orderDetailID`);

--
-- Indexes for table `orderhandled`
--
ALTER TABLE `orderhandled`
  ADD PRIMARY KEY (`ohID`),
  ADD UNIQUE KEY `orderDetailID_UNIQUE` (`orderDetailID`),
  ADD KEY `itDetailID` (`itDetail`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `accIDBuyer` (`accIDBuyer`);

--
-- Indexes for table `pricebook`
--
ALTER TABLE `pricebook`
  ADD PRIMARY KEY (`pbID`),
  ADD KEY `itemID_idx` (`itemID`),
  ADD KEY `countryISOCode_idx` (`countryISOCode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `itidetail`
--
ALTER TABLE `itidetail`
  MODIFY `itIDetailID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `orderdetail`
--
ALTER TABLE `orderdetail`
  MODIFY `orderDetailID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `orderhandled`
--
ALTER TABLE `orderhandled`
  MODIFY `ohID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `pricebook`
--
ALTER TABLE `pricebook`
  MODIFY `pbID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `accaddr`
--
ALTER TABLE `accaddr`
  ADD CONSTRAINT `addrAccID` FOREIGN KEY (`accID`) REFERENCES `acc` (`accID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `addrCountry` FOREIGN KEY (`countryISOCode`) REFERENCES `pricebook` (`countryISOCode`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `accpassport`
--
ALTER TABLE `accpassport`
  ADD CONSTRAINT `passAccID` FOREIGN KEY (`passAccID`) REFERENCES `acc` (`accID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `itidetail`
--
ALTER TABLE `itidetail`
  ADD CONSTRAINT `itID` FOREIGN KEY (`itID`) REFERENCES `itinarary` (`itID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `itinarary`
--
ALTER TABLE `itinarary`
  ADD CONSTRAINT `itAccID` FOREIGN KEY (`accID`) REFERENCES `acc` (`accID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD CONSTRAINT `orderAccIDBuyer` FOREIGN KEY (`accIDBuyer`) REFERENCES `acc` (`accID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderID` FOREIGN KEY (`orderID`) REFERENCES `orders` (`orderID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orderhandled`
--
ALTER TABLE `orderhandled`
  ADD CONSTRAINT `itDetailID` FOREIGN KEY (`itDetail`) REFERENCES `itidetail` (`itIDetailID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderDetailID` FOREIGN KEY (`orderDetailID`) REFERENCES `orderdetail` (`orderDetailID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `accIDBuyer` FOREIGN KEY (`accIDBuyer`) REFERENCES `acc` (`accID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pricebook`
--
ALTER TABLE `pricebook`
  ADD CONSTRAINT `priceItemID` FOREIGN KEY (`itemID`) REFERENCES `item` (`itemID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
