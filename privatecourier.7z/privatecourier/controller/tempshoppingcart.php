<?php 

include '../model/database.php';

session_start();

$accIDBuyer=mysqli_real_escape_string($connect,$_SESSION["accID"]);
$dimH=mysqli_real_escape_string($connect,$_POST["dimH"]);
$dimW=mysqli_real_escape_string($connect,$_POST["dimW"]);
$dimD=mysqli_real_escape_string($connect,$_POST["dimD"]);
$weight=mysqli_real_escape_string($connect,$_POST["weight"]);
/*$currency=mysqli_real_escape_string($connect,$_POST["currency"]);*/
$amount=mysqli_real_escape_string($connect,$_POST["amount"]);
$courierFee=mysqli_real_escape_string($connect,$_POST["courierFee"]);
$pbID=mysqli_real_escape_string($connect,$_GET["pb"]);

$sql2="SELECT currency 
       FROM pricebook
       WHERE pbID='$pbID'";
$result2=$connect->query($sql2);
$currency=$result2->fetch_assoc()["currency"];

echo $query="INSERT INTO orderTemp (accIDBuyer, pbID, dimH, dimW, dimD, weight, currency, amount, courierFee)
		VALUES ('$accIDBuyer', '$pbID', '$dimH', '$dimW', '$dimD', '$weight', '$currency', '$amount', '$courierFee')";

echo mysqli_error($connect);

if ($_POST["amount"] != 0 && $_POST["courierFee"] != 0) 
{
	mysqli_query($connect, $query);
	header("Location: ../view/viewcart.php");
}
?>
