<?php include '../model/database.php';?>

<?php
session_start();  

if(isset($_POST['btn-login']))  
{  
    $user_ID=mysqli_real_escape_string($connect,$_POST['accID']);  
    $user_pass=mysqli_real_escape_string($connect,$_POST['accPasswd']);  
  
    $check_user = "SELECT * FROM acc WHERE accID='$user_ID' AND accPasswd='$user_pass'";  
  
    $run=mysqli_query($connect,$check_user);  
  
    if(mysqli_num_rows($run))  
    {  
        $_SESSION['accID']=$user_ID;//here session is used and value of $user_email store in $_SESSION.  
        /*header('Location: welcome.php');*/
        echo "<script type='text/javascript'>";
        echo "alert('Welcome $user_ID');
        location.href='../view/welcome.php';";    
        echo "</script>";
    }  
    else  
    {  
        echo "<script type='text/javascript'>";
        echo "alert('Incorrect user ID or password!');
        location.href='../view/login.php';";    
        echo "</script>";
    }  
}  
?>