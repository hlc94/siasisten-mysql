<?php

	include '../model/database.php';

	session_start();

	$passAccID=mysqli_real_escape_string($connect,$_SESSION["accID"]);
	$passNo=mysqli_real_escape_string($connect,$_POST["passNo"]);
	$passName=mysqli_real_escape_string($connect,$_POST["passName"]);
	$passDOB=mysqli_real_escape_string($connect,$_POST["passDOB"]);
	$passPOB=mysqli_real_escape_string($connect,$_POST["passPOB"]);
	$passNat=mysqli_real_escape_string($connect,$_POST["passNat"]);
	$passDateExp=mysqli_real_escape_string($connect,$_POST["passDateExp"]);
	$passIssueOff=mysqli_real_escape_string($connect,$_POST["passIssueOff"]);

	$sql="INSERT IGNORE INTO `accpassport` (`passAccID`, `passNo`, `passName`, `passDOB`, `passPOB`, `passNat`, `passDateExp`, `passIssueOff`)
		  VALUES ('$passAccID', '$passNo', '$passName', '$passDOB', '$passPOB', '$passNat', '$passDateExp', '$passIssueOff')";

	mysqli_query($connect,$sql);

	if(mysqli_affected_rows($connect) > 0){
		echo "<script type='text/javascript'>";
	    echo "alert('Passport credentials updated');
	    location.href='../view/welcome.php';";    
	    echo "</script>";
	} else {
		echo "<script type='text/javascript'>";
	    echo "alert('Passport update failed');
	    location.href='../view/welcome.php';";    
	    echo "</script>";
	}

	mysqli_close($connect);
		
?>

