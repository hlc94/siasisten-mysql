<?php include '../model/database.php';

session_start();

if (isset($_POST["submit"]))
{
	$itemID=mysqli_real_escape_string($connect,$_GET['id']);
	$description=mysqli_real_escape_string($connect,$_POST['description']);
	$type=mysqli_real_escape_string($connect,$_POST['type']);
	$itemNumber=mysqli_real_escape_string($connect,$_POST['itemNumber']);
	$brand=mysqli_real_escape_string($connect,$_POST['brand']);

	$target_dir = "../model/images/";
	$target_file = $target_dir . basename($_FILES["imgPath"]["name"]);

	move_uploaded_file($_FILES["imgPath"]["tmp_name"], $target_file);

	$query = "UPDATE `item` SET `description`='$description',`type`='$type',`itemNumber`='$itemNumber',`brand`='$brand', `imgPath`='$target_file' WHERE `itemID`='$itemID'";

	mysqli_query($connect, $query);

	if(mysqli_affected_rows($connect) >= 1){
		echo "<script type='text/javascript'>";
	    echo "alert('Item data edited successfully');
	    location.href='../view/viewItems.php';";    
	    echo "</script>";
	} else {
		echo "<script type='text/javascript'>";
	    echo "alert('Item data edit failed');
	    location.href='../view/viewItems.php';";    
	    echo "</script>";
	}
}
mysqli_close($connect);
?>