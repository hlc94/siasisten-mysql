<?php include '../model/database.php';

session_start();

$itemID=mysqli_real_escape_string($connect,$_POST['itemID']);
$description=mysqli_real_escape_string($connect,$_POST['description']);
$type=mysqli_real_escape_string($connect,$_POST['type']);
$itemNumber=mysqli_real_escape_string($connect,$_POST['itemNumber']);
$brand=mysqli_real_escape_string($connect,$_POST['brand']);

$target_dir = "../model/images/";
$target_file = $target_dir . basename($_FILES["imgPath"]["name"]);

move_uploaded_file($_FILES["imgPath"]["tmp_name"], $target_file);

$sql="INSERT INTO item 
	  VALUES ('$itemID', '$description', '$type', '$itemNumber', '$brand', '$target_file')";

mysqli_query($connect, $sql);

if(mysqli_affected_rows($connect) > 0){
	echo "<script type='text/javascript'>";
    echo "alert('New item added');
    location.href='../view/viewItems.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Item addition failed');
    location.href='../view/viewItems.php';";    
    echo "</script>";
}
mysqli_close($connect);
?>