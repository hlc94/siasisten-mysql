<?php

include '../model/database.php';

session_start();

$accID=mysqli_real_escape_string($connect,$_SESSION["accID"]);

$itIDetailID=mysqli_real_escape_string($connect,$_GET["id"]);
$bookNo=mysqli_real_escape_string($connect,$_POST["bookNo"]);
$depCountry=mysqli_real_escape_string($connect,$_POST["depCountry"]);
$depCity=mysqli_real_escape_string($connect,$_POST["depCity"]);
$depDate=mysqli_real_escape_string($connect,$_POST["depDate"]);
$flightNo=mysqli_real_escape_string($connect,$_POST["flightNo"]);
$airline=mysqli_real_escape_string($connect,$_POST["airline"]);
$arrCountry=mysqli_real_escape_string($connect,$_POST["arrCountry"]);
$arrCity=mysqli_real_escape_string($connect,$_POST["arrCity"]);
$arrDate=mysqli_real_escape_string($connect,$_POST["arrDate"]);



$sql="UPDATE `itidetail` 
	  SET 
	  
	  bookNo='$bookNo',
	  depCountry='$depCountry',
	  depCity='$depCity',
	  depDate='$depDate',
	  flightNo='$flightNo',
	  airline='$airline',
	  arrCountry='$arrCountry',
	  arrCity='$arrCity',
	  arrDate='$arrDate'
	  WHERE itIDetailID='$itIDetailID'";

mysqli_query($connect,$sql);

if(mysqli_affected_rows($connect) >= 1){
	echo "<script type='text/javascript'>";
    echo "alert('Itinerary updated');
    location.href='../view/itiView.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Failed to update itinerary');
    location.href='../view/itiView.php';";    
    echo "</script>";
}
mysqli_close($connect);
?>