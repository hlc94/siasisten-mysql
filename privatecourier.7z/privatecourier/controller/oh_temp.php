<?php

include '../model/database.php';

session_start();

$accID=mysqli_real_escape_string($connect,$_SESSION["accID"]);
$orderDetailID=mysqli_real_escape_string($connect,$_GET["od"]);
$itDetail=mysqli_real_escape_string($connect,$_GET["itdetail"]);

$sql="INSERT IGNORE INTO `orderhandled_temp` (accID, orderDetailID, itDetail)
	  VALUES ('$accID', '$orderDetailID', '$itDetail')";

mysqli_query($connect,$sql);
header("Location:../view/tempOhView.php");

mysqli_close($connect);
?>