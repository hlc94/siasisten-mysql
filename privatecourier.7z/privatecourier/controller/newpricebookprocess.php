<?php include '../model/database.php';

$countryISOCode=mysqli_real_escape_string($connect,$_POST['countryISOCode']);
$itemID=mysqli_real_escape_string($connect,$_POST['itemID']);
$currency=mysqli_real_escape_string($connect,$_POST['currency']);
$sellPrice=mysqli_real_escape_string($connect,$_POST['sellPrice']);
$courierFee=mysqli_real_escape_string($connect,$_POST['courierFee']);
$itemCOGS=mysqli_real_escape_string($connect,$_POST['itemCOGS']);
$handlingCost=mysqli_real_escape_string($connect,$_POST['handlingCost']);
$tax=mysqli_real_escape_string($connect,$_POST['tax']);
$active=mysqli_real_escape_string($connect,$_POST['active']);


mysqli_query($connect, "INSERT INTO pricebook (countryISOCode, itemID, currency, sellPrice, courierFee, itemCOGS, handlingCost, tax, active) 
	VALUES ('$countryISOCode', '$itemID', '$currency', '$sellPrice', '$courierFee', '$itemCOGS', '$handlingCost', '$tax', '$active')");

if(mysqli_affected_rows($connect) > 0){
	echo "<script type='text/javascript'>";
    echo "alert('Price book added');
    location.href='../view/showpricebook.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Price book addition failed');
    location.href='../view/showpricebook.php';";    
    echo "</script>";
}
mysqli_close($connect);
?>