<?php include '../model/database.php';

session_start();

$pbID=mysqli_real_escape_string($connect,$_GET["id"]);
$countryISOCodenew=mysqli_real_escape_string($connect,$_POST['countryISOCode']);
$currencynew=mysqli_real_escape_string($connect,$_POST['currency']);
$sellPricenew=mysqli_real_escape_string($connect,$_POST['sellPrice']);
$courierFeenew=mysqli_real_escape_string($connect,$_POST['courierFee']);
$itemCOGSnew=mysqli_real_escape_string($connect,$_POST['itemCOGS']);
$handlingCostnew=mysqli_real_escape_string($connect,$_POST['handlingCost']);
$taxnew=mysqli_real_escape_string($connect,$_POST['tax']);
$activenew=mysqli_real_escape_string($connect,$_POST['active']);

$query = "UPDATE pricebook 
SET countryISOCode='$countryISOCodenew', currency='$currencynew',
sellPrice='$sellPricenew', courierFee='$courierFeenew', itemCOGS='$itemCOGSnew', handlingCost='$handlingCostnew', 
tax='$taxnew', active='$activenew'
WHERE pbID='$pbID'";

mysqli_query($connect, $query);

if(mysqli_affected_rows($connect) >= 1){
	echo "<script type='text/javascript'>";
    echo "alert('Price book edited successfully');
    location.href='../view/showpricebook.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Price book edit failed');
    location.href='../view/showpricebook.php';";    
    echo "</script>";
}
mysqli_close($connect);
?>