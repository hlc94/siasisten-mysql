<?php include '../model/database.php';?>

<?php
session_start();

$accID=mysqli_real_escape_string($connect,$_SESSION['accID']);
$accPasswd=mysqli_real_escape_string($connect,$_POST['accPasswd']);
$name=mysqli_real_escape_string($connect,$_POST['name']);
$nik=mysqli_real_escape_string($connect,$_POST['nik']);

mysqli_query($connect, "UPDATE acc set accPasswd='$accPasswd', name='$name', nik='$nik' WHERE accID='$accID'");

if(mysqli_affected_rows($connect) > 0){
	echo "<script type='text/javascript'>";
    echo "alert('Account edited successfully');
    location.href='../view/welcome.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Failed to edit account');
    location.href='../view/updateacc.php';";    
    echo "</script>";
}
mysqli_close($connect);
?>