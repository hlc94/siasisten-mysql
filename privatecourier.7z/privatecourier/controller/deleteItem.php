<?php

include '../model/database.php';

session_start();

$itemID=mysqli_real_escape_string($connect, $_GET["id"]);

$sql="DELETE FROM item WHERE itemID='$itemID'";

mysqli_query($connect,$sql);

if(mysqli_affected_rows($connect) > 0){
	echo "<script type='text/javascript'>";
    echo "alert('Item deleted');
    location.href='../view/viewItems.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Item deletion failed');
    location.href='../view/viewItems.php';";    
    echo "</script>";
}

?>