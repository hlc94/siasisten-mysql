<?php include '../model/database.php';

session_start();

$itIDetailID=$_GET["id"];

mysqli_query($connect, "DELETE FROM `itidetail` WHERE itIDetailID='$itIDetailID'");

if(mysqli_affected_rows($connect) > 0){
	echo "<script type='text/javascript'>";
    echo "alert('Itinerary deleted');
    location.href='../view/itiView.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Failed to delete itinerary');
    location.href='../view/itiView.php';";    
    echo "</script>";
}

?>