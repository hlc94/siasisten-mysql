<?php include '../model/database.php';
session_start();

$accID=mysqli_real_escape_string($connect,$_SESSION['accID']);
$addrID=mysqli_real_escape_string($connect,$_POST['addrID']);
$addrType=mysqli_real_escape_string($connect,$_POST['addrType']);
$prov=mysqli_real_escape_string($connect,$_POST['prov']);
$kota_kab=mysqli_real_escape_string($connect,$_POST['kota_kab']);
$kec=mysqli_real_escape_string($connect,$_POST['kec']);
$addr=mysqli_real_escape_string($connect,$_POST['addr']);
$zip=mysqli_real_escape_string($connect,$_POST['zip']);
$countryISOCode=mysqli_real_escape_string($connect,$_POST['countryISOCode']);

/*echo */$sql="INSERT INTO `accaddr` (accID, addrID, addrType, prov, kota_kab, kec, addr, zip, countryISOCode) 
	  VALUES ('$accID', '$addrID', '$addrType', '$prov', '$kota_kab', '$kec', '$addr', '$zip', '$countryISOCode')";

mysqli_query($connect,$sql);
/*echo mysqli_error($connect);*/


if(mysqli_affected_rows($connect) > 0){
	echo "<script type='text/javascript'>";
	echo "alert('Address updated');
	location.href='../view/viewAddress.php';";	
	echo "</script>";
} else {
	echo "<script type='text/javascript'>";
	echo "alert('Address update failed');
	location.href='../view/viewAddress.php';";	
	echo "</script>";
}

mysqli_close($connect);
?>