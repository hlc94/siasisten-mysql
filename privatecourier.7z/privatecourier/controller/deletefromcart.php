<?php 

	include '../model/database.php';

	session_start();

	$accIDBuyer=mysqli_real_escape_string($connect,$_SESSION["accID"]);

	
	$itemID=mysqli_real_escape_string($connect,$_GET["id"]);
	$dimH=mysqli_real_escape_string($connect,$_GET["h"]);
	$dimW=mysqli_real_escape_string($connect,$_GET["w"]);
	$dimD=mysqli_real_escape_string($connect,$_GET["d"]);
	$weight=mysqli_real_escape_string($connect,$_GET["weight"]);
	$currency=mysqli_real_escape_string($connect,$_GET["currency"]);
	$amount=mysqli_real_escape_string($connect,$_GET["amount"]);
	$courierFee=mysqli_real_escape_string($connect,$_GET["fee"]);

	$query="DELETE FROM ordertemp 
			WHERE accIDBuyer='$accIDBuyer' 
			AND itemID='$itemID' 
			AND dimH='$dimH' 
			AND dimW='$dimW'
			AND dimD='$dimD'
			AND weight='$weight'
			AND currency='$currency'
			AND amount='$amount'
			AND courierFee='$courierFee'";

	mysqli_query($connect,$query);
	/*echo mysqli_error($connect);*/
	
	if(mysqli_affected_rows($connect) > 0){
		echo "<script type='text/javascript'>";
	    echo "alert('Order deleted');
	    location.href='../view/viewcart.php';";    
	    echo "</script>";
	} else {
		echo "<script type='text/javascript'>";
	    echo "alert('Failed to delete order');
	    location.href='../view/viewcart.php';";    
	    echo "</script>";
	}
?>