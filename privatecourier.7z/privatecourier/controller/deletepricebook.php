<?php include '../model/database.php';

session_start();

$pbID=$_GET["id"];

mysqli_query($connect, "DELETE FROM pricebook WHERE pbID='$pbID'");

if(mysqli_affected_rows($connect) > 0){
	echo "<script type='text/javascript'>";
    echo "alert('Pricebook deleted');
    location.href='../view/showpricebook.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Failed to delete pricebook');
    location.href='../view/showpricebook.php';";    
    echo "</script>";
}

?>

