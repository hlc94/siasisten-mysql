<?php
include '../model/database.php';

session_start();

$accID=mysqli_real_escape_string($connect,$_SESSION["accID"]);

$itID=mysqli_real_escape_string($connect,$_POST["itID"]);

echo $sql1="INSERT INTO `itinarary`(`itID`, `accID`, `itBookID`)
	   VALUES ('$itID', '$accID', 'itBookID')";

mysqli_query($connect,$sql1);

foreach($_POST["depCity"] as $key=>$val)
{
	$depCity=$val;
	$bookNo=mysqli_real_escape_string($connect,$_POST["bookNo"][$key]);
	$depCountry=mysqli_real_escape_string($connect,$_POST["depCountry"][$key]);
	$depDate=mysqli_real_escape_string($connect,$_POST["depDate"][$key]);
	$flightNo=mysqli_real_escape_string($connect,$_POST["flightNo"][$key]);
	$airline=mysqli_real_escape_string($connect,$_POST["airline"][$key]);
	$arrCountry=mysqli_real_escape_string($connect,$_POST["arrCountry"][$key]);
	$arrCity=mysqli_real_escape_string($connect,$_POST["arrCity"][$key]);
	$arrDate=mysqli_real_escape_string($connect,$_POST["arrDate"][$key]);

	$sql="INSERT INTO `itidetail`(`itID`, `bookNo`, `depCountry`, `depCity`, `depDate`, `flightNo`, `airline`, `arrCountry`, `arrCity`, `arrDate`)
		  VALUES ('$itID', '$bookNo', '$depCountry', '$depCity', '$depDate', '$flightNo', '$airline', '$arrCountry', '$arrCity', '$arrDate')";

	mysqli_query($connect,$sql);
}

if(mysqli_affected_rows($connect) > 0){
	$sql2="DELETE FROM tempitinerary WHERE accID='$accID'";
	mysqli_query($connect,$sql2);
	echo "<script type='text/javascript'>";
    echo "alert('Itinerary created');
    location.href='../view/itiView.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Failed to create itinerary');
    location.href='../view/itiView.php';";    
    echo "</script>";
}
mysqli_close($connect);
?>