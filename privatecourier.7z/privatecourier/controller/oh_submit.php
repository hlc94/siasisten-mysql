<?php  

include '../model/database.php';
session_start();

$accID=$_SESSION["accID"];

echo $sql="INSERT INTO `orderhandled` (orderDetailID, itDetail)
	  SELECT orderDetailID, itDetail
	  FROM `orderhandled_temp`
	  WHERE accID='$accID'";

mysqli_query($connect,$sql);
/*
echo mysqli_error($connect);*/

if(mysqli_affected_rows($connect) > 0){
	echo $delsql="DELETE FROM orderhandled_temp
			 WHERE orderhandled_temp.accID='$accID'";
	echo mysqli_query($connect,$delsql);
	echo "<script type='text/javascript'>";
    echo "alert('Order(s) successfully booked');
    location.href='../view/maketrip.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Order booking failed');
    location.href='../view/maketrip.php';";
    echo "</script>";
}

?>