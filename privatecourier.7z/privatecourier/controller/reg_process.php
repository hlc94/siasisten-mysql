<?php 

	include '../model/database.php';

	$accID=mysqli_real_escape_string($connect,$_POST['accID']);
	$accPasswd=mysqli_real_escape_string($connect,$_POST['accPasswd']);
	$name=mysqli_real_escape_string($connect,$_POST['name']);
	$nik=mysqli_real_escape_string($connect,$_POST['nik']);

	$sql="SELECT * FROM acc WHERE accID='$accID'";

	$get_user=mysqli_query($connect,$sql);

	$get_row=mysqli_affected_rows($connect);

	if($get_row>=1){
		echo "<script type='text/javascript'>";
	    echo "alert('Username already exists!');
	    location.href='view/index.php';";    
	    echo "</script>";	
	} else {
		mysqli_query($connect, "INSERT INTO acc (accID, accPasswd, name, nik, accDateCreate) 
					VALUES ('$accID', '$accPasswd', '$name', '$nik', CURRENT_TIMESTAMP())");	

		if(mysqli_affected_rows($connect) > 0){
			echo "<script type='text/javascript'>";
		    echo "alert('Successfully registered');
		    location.href='../view/login.php';";    
		    echo "</script>";
		} else {
			echo "<script type='text/javascript'>";
		    echo "alert('Registration failed');
		    location.href='../view/login.php';";    
		    echo "</script>";
		}
	}

	mysqli_close($connect);
?>