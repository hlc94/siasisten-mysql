<?php 

include '../model/database.php';

session_start();

$accID=mysqli_real_escape_string($connect,$_SESSION["accID"]);
$bookNo=mysqli_real_escape_string($connect,$_POST["bookNo"]);
$depCountry=mysqli_real_escape_string($connect,$_POST["depCountry"]);
$depCity=mysqli_real_escape_string($connect,$_POST["depCity"]);
$depDate=mysqli_real_escape_string($connect,$_POST["depDate"]);
$flightNo=mysqli_real_escape_string($connect,$_POST["flightNo"]);
$airline=mysqli_real_escape_string($connect,$_POST["airline"]);
$arrCountry=mysqli_real_escape_string($connect,$_POST["arrCountry"]);
$arrCity=mysqli_real_escape_string($connect,$_POST["arrCity"]);
$arrDate=mysqli_real_escape_string($connect,$_POST["arrDate"]);

$sql="INSERT INTO `tempitinerary`(`accID`, `bookNo`, `depCountry`, `depCity`, `depDate`, `flightNo`, `airline`, `arrCountry`, `arrCity`, `arrDate`) 
	  VALUES ('$accID', '$bookNo', '$depCountry', '$depCity', '$depDate', '$flightNo', '$airline', '$arrCountry', '$arrCity', '$arrDate')";

mysqli_query($connect, $sql);

if (mysqli_affected_rows($connect) > 0) 
{
	echo "Itinerary created";
	header("Location: ../view/tempItiView.php");
}

?>