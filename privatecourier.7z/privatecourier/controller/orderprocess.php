<?php include '../model/database.php';

session_start();

$accIDBuyer=mysqli_real_escape_string($connect,$_SESSION["accID"]);

$addrShipID=mysqli_real_escape_string($connect,$_POST["addrShipID"]);

$query2 ="INSERT IGNORE INTO `orders` (accIDBuyer, orderDate, addrShipID, payID, payStatus)
		  VALUES ('$accIDBuyer', CURRENT_TIMESTAMP, '$addrShipID', 1, 'U')";

mysqli_query($connect,$query2);

foreach($_POST["pbID"] as $key=>$val) 
{
	$pbID=$val;	
	$dimH=mysqli_real_escape_string($connect,$_POST["dimH"][$key]);
	$dimW=mysqli_real_escape_string($connect,$_POST["dimW"][$key]);
	$dimD=mysqli_real_escape_string($connect,$_POST["dimD"][$key]);
	$weight=mysqli_real_escape_string($connect,$_POST["weight"][$key]);
	$currency=mysqli_real_escape_string($connect,$_POST["currency"][$key]);
	$amount=mysqli_real_escape_string($connect,$_POST["amount"][$key]);
	$courierFee=mysqli_real_escape_string($connect,$_POST["courierFee"][$key]);
	
	$lastOrderID="SELECT * from `orders` WHERE accIDBuyer='$accIDBuyer' ORDER BY `orderID` DESC LIMIT 1";
	$result=$connect->query($lastOrderID);
	$resorder=$result->fetch_assoc()["orderID"];

	$query1="INSERT IGNORE INTO `orderdetail` (orderID, pbID, accIDBuyer, dimH, dimW, dimD, weight, currency, amount, courierFee)
			 SELECT orderID, '$pbID', '$accIDBuyer', '$dimH', '$dimW', '$dimD', '$weight', '$currency', '$amount', '$courierFee' 
			 FROM `orders`
			 WHERE accIDBuyer='$accIDBuyer'
			 ORDER BY orderID DESC
			 LIMIT 1";

	if ($_POST["amount"] != 0 && $_POST["currency"] != "" && $_POST["courierFee"] != 0) 
	{
		mysqli_query($connect,$query1);				
	}
}

if(mysqli_affected_rows($connect) > 0){
	$delquery="DELETE FROM ordertemp WHERE
			   accIDBuyer='$accIDBuyer'";
	mysqli_query($connect,$delquery);
	echo "<script type='text/javascript'>";
    echo "alert('Order placed');
    location.href='../view/welcome.php';";    
    echo "</script>";
} else {
	echo "<script type='text/javascript'>";
    echo "alert('Order placement failed');
    location.href='../view/viewcart.php';";    
    echo "</script>";
}
mysqli_close($connect);

?>